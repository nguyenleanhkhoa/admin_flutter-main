//
//  Generated file. Do not edit.
//

import FlutterMacOS
import Foundation

import animated_progress_bar
import file_selector_macos
import path_provider_foundation

func RegisterGeneratedPlugins(registry: FlutterPluginRegistry) {
  AnimatedProgressBarPlugin.register(with: registry.registrar(forPlugin: "AnimatedProgressBarPlugin"))
  FileSelectorPlugin.register(with: registry.registrar(forPlugin: "FileSelectorPlugin"))
  PathProviderPlugin.register(with: registry.registrar(forPlugin: "PathProviderPlugin"))
}
