class ContactList {
  String position;
  String name;
  String email;
  String tages;
  String image;

  ContactList({
    required this.image,
    required this.email,
    required this.name,
    required this.position,
    required this.tages,
  });
}
