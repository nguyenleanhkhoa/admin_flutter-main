class Emails {
  String name;
  String time;
  String subtext;
  Emails({
    required this.name,
    required this.time,
    required this.subtext,
  });
}
