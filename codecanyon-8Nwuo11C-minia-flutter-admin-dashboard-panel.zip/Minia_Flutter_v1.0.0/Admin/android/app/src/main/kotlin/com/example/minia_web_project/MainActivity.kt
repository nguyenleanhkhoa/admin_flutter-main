package com.example.minia_web_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
